// Copyright (C) 2008  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_SMART_POINTERs_THREAD_SAFE_H_
#define DLIB_SMART_POINTERs_THREAD_SAFE_H_ 

#include "smart_pointers/shared_ptr_thread_safe.h"

#endif // DLIB_SMART_POINTERs_THREAD_SAFE_H_ 



