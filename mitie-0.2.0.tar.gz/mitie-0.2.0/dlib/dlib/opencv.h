// Copyright (C) 2009  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_OPEnCV_HEADER
#define DLIB_OPEnCV_HEADER

#include "opencv/cv_image.h"
#include "opencv/to_open_cv.h"

#endif // DLIB_OPEnCV_HEADER




